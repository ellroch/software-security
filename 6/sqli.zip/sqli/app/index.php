<html>
<body>

<h1>Search for User Information</h1>

<!-- Borrowed with adjustments from https://www.w3schools.com/php/php_forms.asp -->
<form action="search.php" method="post">
Username: <input type="text" name="username"><br>
<input type="submit">
</form>

</body>
</html>
