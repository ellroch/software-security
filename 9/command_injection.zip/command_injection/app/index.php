<html>
<body>

<h1>Count Words!</h1>

<p>Enter a word or phrase to search for in the lorem file and count!</p>

<form action="/" method="post">
Search: <input type="text" name="search"><br>
<input type="submit">
</form>

<h3>
<?php
  // check if url parameter "search" exists and count how many times that string is in 
  // the file lorem.txt
  if (isset($_POST["search"])) {
    $cmd = "grep -oiF " . $_POST["search"] . " lorem.txt | wc -l";
    $count = exec($cmd);
    $out = $count . " instances of the search term " . $_POST['search'];
  }
  else {
    $out = "No search term present";
  }
  // print the count
  echo $out;
 ?>
</h3>

</body>
</html>
