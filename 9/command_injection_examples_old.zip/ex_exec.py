#!/usr/bin/env python3

userinfo = [
    {'username': 'shawn', 'email': 'shawn.zwach@dsu.edu', 'id': 10},
    {'username': 'chad', 'email': 'chad.mitzel@dsu.edu', 'id': 20},
    {'username': 'cody', 'email': 'cody.welu@dsu.edu', 'id': 30}
]

admin = False

def get_user(name):
    info = None
    for user in userinfo:
        if user['username'] == name:
            info = user
    if info:
        print("Username: {}".format(info['username']))
        print("   Email: {}".format(info['email']))
        print("      ID: {}".format(info['id']))
    else:
        print("User not found")

def add_user(name):
    if not admin:
        print("You must be admin to add a user")
    else:
        print("Enter user info")

print("Select a command:")
print("  get - lists user information for a user")
print("  add - add a user to the list")

f =   input(" Command: ")
arg = input("Argument: ")

exec("{}_user('{}')".format(f, arg))
