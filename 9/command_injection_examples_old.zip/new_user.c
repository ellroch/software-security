#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <utmp.h>

int main()
{
  char user[30];
  //char cmd[100];
  printf("Enter a username to see if they're logged in\n");
  printf("Username: ");
  scanf("%25s", user);
  //snprintf(cmd, sizeof(cmd)-1, "w | grep -i %s", user);

  // get utmp
  int count = 0;
  struct utmp* users;
  setutent(); // rewinds utmp 
  users = getutent(); // gets first entry
  while (users)
  {
	  if (strncmp(users->ut_user,user, sizeof(user)) == 0)
		  count++;
	  users = getutent();
  }
  printf("Sessions: %d\n", count);
  //fflush(stdout);
  //system(cmd);
  return 0;
}
