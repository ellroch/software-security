#include <stdio.h>
#include <stdlib.h>

int main()
{
  char user[30];
  char cmd[100];
  printf("Enter a username to see if they're logged in\n");
  printf("Username: ");
  scanf("%25s", user);
  snprintf(cmd, sizeof(cmd)-1, "w | grep -i %s", user);
  printf("User sessions:\n");
  fflush(stdout);
  system(cmd);
  return 0;
}
