#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define DBUF 100
#define CBUF 250

int main()
{
  // quick program to get an IP from a hostname

  // variables
  char domain[DBUF];
  char command[CBUF];

  // get input
  printf("Enter a domain to get IPs: ");
  fgets(domain, DBUF, stdin);
  domain[strnlen(domain, DBUF)-1]= '\0'; // make sure strings is null terminated intead of \n...

  // get IPs from hostname
  // nslookup to lookup IP by hostname
  // filter out non address information using grep
  // only look at IP instead of label (field 2)
  // get only first IP result with tail & head
  snprintf(command, CBUF, "nslookup %s | grep -i address | awk '{ print $2 }' | tail -n+2 | head -n 1", domain); // build command
  printf("\nFirst IP associated with %s is ", domain);
  fflush(stdout); // Make sure we get output before running command
  system(command); // run command
  return 0;
}
