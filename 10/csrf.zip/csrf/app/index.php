<?php session_start(); ?>
<html>
<body>

<h1>Transfer Money</h1>

<?php
  // setup account info
  if (!isset($_SESSION["balance"])) // if session doesn't have a balance - set one
	  $_SESSION["balance"] = 2500;

  // process form if GET parameters present
  if (isset($_GET["account"]) && isset($_GET["amount"]))
  {
	  // effectively ignore account since we don't have a database
	  // if amount is a number
	  if (is_numeric($_GET["amount"]))
	  {
		// subtract amount from the balance
	  	$_SESSION["balance"] -= $_GET["amount"];

		// print resulting operation
	  	echo "You sent $" . htmlentities($_GET["amount"]) . " to " . htmlentities($_GET["account"]);
	  }
	  else
		  echo "Amount must be a number!";
  }
?>

<p>Your Balance: $<?php echo $_SESSION["balance"]; ?></p>

<form action="/" method="get">
Account: <input type="text" name="account"><br>
Amount: <input type="text" name="amount"><br>
<input type="submit" value="Transfer">
</form>

<!-- this is a convenient way to reset the session - you can ignore this too -->
<a href="reset.php">Reset Session/Account Info</a>

</body>
</html>
