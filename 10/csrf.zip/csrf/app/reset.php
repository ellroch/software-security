<?php

	// this page just resets the session for convenience and can be ignored
	session_start();
	session_regenerate_id();
	header('Location: /');
	session_unset();
	session_destroy();
?>
