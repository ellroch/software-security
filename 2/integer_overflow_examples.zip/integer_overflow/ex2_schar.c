#include <stdio.h>

int main()
{
	char c = 255;
	printf("Char is 255: %d\n", c);
	printf("Char is 256: %d\n", c+1);
	printf("Char is 256: %d\n", ++c);
	return 0;
}
