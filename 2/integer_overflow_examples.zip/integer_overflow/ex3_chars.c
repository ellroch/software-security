#include <stdio.h>

int main()
{
	int i;
	unsigned char a=250;
	signed char b=125;

	printf("Unsigned char\n");
	for (i=250; i <= 260; i++)
	{
		printf("%d: %d\n", i, a);
		a++;
	}

	printf("\nSigned char\n");
	for (i=125; i <= 135; i++)
	{
		printf("%d: %d\n", i, b);
		b++;
	}
	return 0;
}
