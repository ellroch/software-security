#include <stdio.h>
#include <limits.h>

int main()
{
	// get some signed ints
	int a, b, result;
	printf("Enter a number: ");
	scanf("%i", &a);
	printf("Enter a number: ");
	scanf("%i", &b);

	printf("INT_MIN: %d\n", INT_MIN);
	printf("INT_MAX: %d\n", INT_MAX);

	// check the safety of the operation
	if (__builtin_add_overflow(a, b, &result))
		printf("Overflow detected - no result\n");
	else
		printf("%d + %d is %d\n", a, b, result);
	return 0;
}
