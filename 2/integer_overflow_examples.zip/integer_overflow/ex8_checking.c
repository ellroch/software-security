#include <stdio.h>
#include <limits.h>

int main()
{
	// get some signed ints
	int a, b;
	printf("Enter a number: ");
	scanf("%i", &a);
	printf("Enter a number: ");
	scanf("%i", &b);

	printf("INT_MIN: %d\n", INT_MIN);
	printf("INT_MAX: %d\n", INT_MAX);

	// check the safety of the operation
	// Example from: https://stackoverflow.com/questions/199333
	// first variable is negative so operation is subtraction
	if (b > 0 && a > INT_MAX - b)
		printf("Cannot compute - overflow\n");
	
	// first variable is positive so operation is addition
	else if (b < 0 && a < INT_MIN - b)
		printf("Cannot computer - underflow\n");
	else
		printf("%d + %d = %d\n", a, b, a+b);
	return 0;
}
