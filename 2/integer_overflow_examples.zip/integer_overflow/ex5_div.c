#include <stdio.h>

int main()
{
	signed char a = -128;
	printf("a is %d\n", a);
	a /= -1;
	printf("a is %d\n", a);
	return 0;
}
