#include <stdio.h>

int main()
{
	unsigned int big = 4294967295;
	char small = -1;
	printf("%d mod %u = %u\n", small, big, small % big);
	return 0;
}
