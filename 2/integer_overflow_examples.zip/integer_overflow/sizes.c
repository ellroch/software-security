#include <stdio.h>

int main()
{
	char c;
	short s;
	int i;
	long l;
	float f;
	double d;

	printf("   char: %ld\n", sizeof(c));
	printf("  short: %ld\n", sizeof(s));
	printf("    int: %ld\n", sizeof(i));
	printf("   long: %ld\n", sizeof(l));
	printf("  float: %ld\n", sizeof(f));
	printf(" double: %ld\n", sizeof(d));

	return 0;
}
