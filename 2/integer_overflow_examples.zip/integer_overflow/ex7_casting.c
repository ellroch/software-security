#include <stdio.h>

int main()
{
	unsigned int a = 0xffffffff;
	char b = -1;
	printf("a: %u\nb: %d\n", a, b);
	if (a == b)
		printf("Whoops\n");
	return 0;
}
