#include <stdio.h>

int main()
{
	unsigned char a = 100;
	printf("a is %d\n", a);
	a = a * 3;
	printf("a is %d\n", a);
	return 0;
}
