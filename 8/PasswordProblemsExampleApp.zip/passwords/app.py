from flask import Flask, render_template, request
from flask_sqlalchemy import SQLAlchemy
from hashlib import md5, sha256
import bcrypt
from base64 import b64encode

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///./test.db'
db = SQLAlchemy(app)

class User(db.Model):
    id       = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(100), nullable=False)
    password = db.Column(db.String(500), nullable=False)
    example  = db.Column(db.Integer, nullable=False, unique=True)

def get_user_by_example(example_number):
    return User.query.filter_by(example=example_number).first() # fetches the user created for the example

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/dump/<int:example>')
def dump(example=None):
    if example:
        user = get_user_by_example(example)
        if user:
            return render_template("dump.html", user=user)
    return render_template("dump.html")

@app.route('/ex1', methods=['GET', 'POST']) # borrowed from another website
def ex_one():
    msg = None
    if request.method == 'POST': # when the form is submitted get the user data
        username = request.form.get('username')
        password = request.form.get('password')
        if "user" == username and "password" == password: # compare the username and password
            msg = "Welcome user!"
        else:
            msg = "Failed login :("
    return render_template('ex1.html', message=msg)

@app.route('/ex2', methods=['GET', 'POST'])
def ex_two():
    msg = None
    if request.method == 'POST': # when the form is submitted get the user data
        username = request.form.get('username')
        password = request.form.get('password')
        user = get_user_by_example(2)
        if user and user.username == username and user.password == password:  # compare the username and password
            msg = "Welcome user!"
        else:
            msg = "Failed login :("
    return render_template('ex2.html', example=2, message=msg)

@app.route('/ex3', methods=['GET', 'POST'])
def ex_three():
    msg = None
    if request.method == 'POST': # when the form is submitted get the user data
        username = request.form.get('username')
        password = request.form.get('password')
        user = get_user_by_example(3)
        if user and user.username == username and user.password == b64encode(password.encode('utf-8')).decode('utf-8'): # compare the username and password
            msg = "Welcome user!"
        else:
            msg = "Failed login :("
    return render_template('ex2.html', example=3, message=msg)

@app.route('/ex4', methods=['GET', 'POST'])
def ex_four():
    msg = None
    if request.method == 'POST': # when the form is submitted get the user data
        username = request.form.get('username')
        password = request.form.get('password')
        user = get_user_by_example(4)
        chkpass = md5()
        chkpass.update(password.encode('utf-8'))
        if user and user.username == username and user.password == chkpass.hexdigest(): # compare the username and password
            msg = "Welcome user!"
        else:
            msg = "Failed login :("
    return render_template('ex2.html', example=4, message=msg)

@app.route('/ex5', methods=['GET', 'POST'])
def ex_five():
    msg = None
    if request.method == 'POST': # when the form is submitted get the user data
        username = request.form.get('username')
        password = request.form.get('password')
        user = get_user_by_example(5)
        chkpass = md5()
        chkpass.update(password.encode('utf-8'))
        if user:
            if user.username == username:
                if user.password == chkpass.hexdigest(): # compare the username and password
                    msg = "Welcome user!"
                else:
                    msg = "Invalid Password :("
            else:
                msg = "Invalid Username"
        else:
            msg = "User not found :("
    return render_template('ex2.html', example=5, message=msg)

@app.route('/ex6', methods=['GET', 'POST'])
def ex_six():
    msg = None
    if request.method == 'POST': # when the form is submitted get the user data
        username = request.form.get('username')
        password = request.form.get('password')
        user = get_user_by_example(6)
        chkpass = md5()
        if user:
            salt = user.password[:-32] # get all but last 32 bytes
            chkpass.update(salt + password.encode('utf-8')) # combine salt and password from web UI
            if user.username == username and user.password[-32:].decode('utf-8') == chkpass.hexdigest(): # compare the username and password
                msg = "Welcome user!"
            else:
                msg = "Failed login :("
        else:
            msg = "Failed login :("
    return render_template('ex2.html', example=6, message=msg)

@app.route('/ex7', methods=['GET', 'POST'])
def ex_seven():
    msg = None
    if request.method == 'POST': # when the form is submitted get the user data
        username = request.form.get('username')
        password = request.form.get('password')
        user = get_user_by_example(7)
        if user and user.username == username and bcrypt.checkpw(password.encode('utf-8'), user.password): # compare the username and password
            msg = "Welcome user!"
        else:
            msg = "Failed login :("
    return render_template('ex2.html', example=7, message=msg)

if __name__ == '__main__':
    app.run("0.0.0.0") # if the script is run directly listen on all interfaces
