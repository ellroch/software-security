#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main()
{
  srand(time(0));
  printf("Random seeded - providing 5 random values!\n");
  for (int i=0; i < 5; i++)
    printf("%d ", rand() % 1000);
  printf("\n");
  return 0;
}
