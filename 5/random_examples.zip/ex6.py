#!/usr/bin/env python3

import hashlib
from Crypto import Random
from Crypto.Cipher import AES
import base64

def pad(key, bits):
    l = len(key)
    t = (bits/8) - (l % (bits/8))
    return key + "".join(["X" for c in range(int(t))]) # pad key to proper space

def encrypt(key, raw):
    dk = pad(key, 256)                      # pad key to 256 bits
    iv = Random.new().read(AES.block_size)  # generate a random IV using CPRNG
    cipher = AES.new(dk, AES.MODE_CBC, iv)  # create a cipher object
    msgpad = pad(raw, 128)                  # pad the message to 128 bits (size of block)
    return base64.b64encode(iv + cipher.encrypt(msgpad))

def decrypt(key, enc):
    padded = pad(key, 256)
    enc = base64.b64decode(enc)
    iv = enc[:AES.block_size]
    cipher = AES.new(padded, AES.MODE_CBC, iv)
    return cipher.decrypt(enc[AES.block_size:]).decode('utf-8')

print(encrypt("mykey","TEST"))

print(decrypt("mykey", "HpwlTY9k6s9fL5hj9P7zCEfG8Ur3TN7hamheeHr0ur8="))
