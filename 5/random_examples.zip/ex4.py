#!/usr/bin/env python3

import sys
import base64

if len(sys.argv) < 3:
    print("./ex4.py <encrypt/decrypt> <msg>")
    sys.exit(1)

if sys.argv[1][0] == 'e':
    print("Encrypting...")
    dest = ""
    src = "MSG: " + sys.argv[2]
    for c in src:
        dest += chr(ord(c) ^ 44) # this is bad, but not the target of the example
    print("Encrypted {}".format(base64.b64encode(dest.encode('utf-8'))))
elif sys.argv[1][0] == 'd':
    print("Decrypting")
    dest = ""
    src = base64.b64decode(sys.argv[2]).decode('utf-8')
    # remove msg
    src = src[5:]
    for c in src:
        dest += chr(ord(c) ^ 44)
    print("Decrypted {}".format(dest))
