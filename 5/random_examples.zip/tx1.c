#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(int argc, char *argv[])
{
  if (argc != 6)
  {
    printf("Need 5 numbers\n");
    exit(1);
  }
  int nums[5];
  int i, j;

  // load up numbers (target)
  for (i=1; i < 6; i++)
    nums[i-1] = atoi(argv[i]);

  // check entire (approx) entire seed space
  int done = 0;
  unsigned int seed;
  unsigned int update = 0;
  for (seed=1560000000; seed < RAND_MAX && !done; seed++)
  // for (seed=0; seed < RAND_MAX && !done; seed++)
  {
    srand(seed);
    done = 1;
    if (update == 5000)
    {
      printf("Testing: %u\n", seed);
      update = 0;
    }
    for (i=0; i < 5 && done; i++)
    {
      if (rand() % 1000 == nums[i])
         done = 1;
      else
         done = 0;
    }
    update++;
  }
  printf("-----------------------------------\n");
  printf("Seed %u produces:\n", --seed); // subtract 1 from seed++ above
  for (i=0; i < 5; i++)
    printf("%d ", nums[i]);
  printf("\n");
  return 0;
}
