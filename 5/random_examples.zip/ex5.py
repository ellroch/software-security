#!/usr/bin/env python3

import sys
import base64

def encrypt(msg):
    dest = ""
    for c in msg:
        dest += chr(ord(c) ^ 44)
    return dest

def decrypt(msg):
    return encrypt(msg)

if len(sys.argv) < 3:
    print("./ex4.py <encrypt/decrypt> <msg>")
    sys.exit(1)

if sys.argv[1][0] == 'e':
    print("Encrypting...")
    print("Encrypted {}".format(base64.b64encode(encrypt(sys.argv[2]).encode('utf-8'))))
elif sys.argv[1][0] == 'd':
    print("Decrypting")
    print("Decrypted {}".format(decrypt(base64.b64decode(sys.argv[2]).decode('utf-8'))))
