#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main()
{
  // ref https://wiki.sei.cmu.edu/confluence/display/c/MSC30-C.+Do+not+use+the+rand%28%29+function+for+generating+pseudorandom+numbers
  struct timespec ts;
  if (timespec_get(&ts, TIME_UTC) == 0)
  {
    printf("Unable to get time - error\n");
    exit(1);
  }
  srandom(ts.tv_nsec ^ ts.tv_sec);
  printf("%ld\n", ts.tv_nsec ^ ts.tv_sec);
  printf("Random seeded - providing 5 random values!\n");
  for (int i=0; i < 5; i++)
    printf("%ld ", random() % 1000);
  printf("\n");
  return 0;
}
