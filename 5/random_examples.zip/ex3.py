#!/usr/bin/env python3
from hashlib import md5

# two strings
a = "this is"
b = " not that exciting"
print(a)
print(b)
x = md5(a.encode('utf-8') + b.encode('utf-8'))
print(x.hexdigest())

# two different strings
a = "this is not that "
b = "exciting"
print(a)
print(b)
x = md5(a.encode('utf-8') + b.encode('utf-8'))
print(x.hexdigest())
