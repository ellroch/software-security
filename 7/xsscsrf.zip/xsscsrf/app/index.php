<html>
<body>

<h1>Say Hello!</h1>

<form action="/" method="get">
Name: <input type="text" name="name"><br>
<input type="submit">
</form>

<h3>
<?php
  // check if url parameter "name" exists and set out to it if it does
  if (isset($_GET["name"])) {
    $out = "Howdy, " . $_GET["name"] . "!";
  }
  else {
    $out = "No name found :(";
  }
  // print name if it was present
  echo $out;
 ?>
</h3>

</body>
</html>
